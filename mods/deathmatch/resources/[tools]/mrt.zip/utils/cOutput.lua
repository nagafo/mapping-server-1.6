function output(txt)
	outputChatBox("[MRT]#bebebe "..txt, 255, 100, 100, true)
end